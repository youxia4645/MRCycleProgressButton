//
//  ProgressButton.m
//  自定义圆形倒计时按钮
//
//  Created by 慕容剑飞 on 16/6/10.
//  Copyright © 2016年 jike. All rights reserved.
//

#import "MRCycleProgressButton.h"

@implementation MRCycleProgressButton

#pragma mark - 初始化方法
- (instancetype)initWithFrame:(CGRect)frame ProgressLineWidth:(CGFloat)progressLineWidth ProgressLienColor:(UIColor *)progressLineColor ProgressTotalTime:(NSInteger)progressTotalTime
{
    if(self = [super initWithFrame:frame])
    {
        //设置背景色
        self.backgroundColor = [UIColor grayColor];
        
        //为自身属性赋值
        self.progressLineWidth = progressLineWidth;
        self.progressLineColor = progressLineColor;
        self.progressTotalTime = progressTotalTime;
        
        //属性取默认值
        if(self.progressLineWidth == 0)
        {
            self.progressLineWidth = 2.5;
        }
        if(self.progressLineColor == nil)
        {
            self.progressLineColor = [UIColor redColor];
        }
        if(self.progressTotalTime == 0)
        {
            self.progressTotalTime = 5;
        }
        
        //添加定时器
        [self setupTimer];
        
        //为初始进度赋值
        self.progress = 0;
        
    }
    return self;

}

- (void)setProgress:(NSInteger)progress
{
    _progress = progress;
    
    //显示在进度按钮上的倒计时文字
    NSInteger titleNumValue = self.progressTotalTime - progress / (100 / self.progressTotalTime);
    
    [self setTitle:[NSString stringWithFormat:@"%zd%@", titleNumValue,@"s"] forState:UIControlStateNormal];
    
    [self setNeedsDisplay];
}

#pragma mark - 重绘
- (void)drawRect:(CGRect)rect
{
    
    //rect 即是self.bounds
    
    /** 5个要点:
     1. center
     2. 半径
     3. 起始角度
     4. 结束角度
     5. 是否顺时针
     */
   
    CGSize s = rect.size;
    
    //将按钮变成圆形
    self.layer.cornerRadius = s.width * 0.5;
    self.layer.masksToBounds = YES;

    //取出中心点
    CGPoint center = CGPointMake(s.width * 0.5, s.height * 0.5);
    
    CGFloat r = (MIN(s.width, s.height) - self.progressLineWidth) * 0.5;
    
    //进度线起始位置
    CGFloat start = -M_PI_2;
    
    //结束位置
    CGFloat end = 2 * M_PI * (self.progress / 100.0) + start;
    
    //画线路径
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center radius:r startAngle:start endAngle:end clockwise:YES];

    //设置线圈的颜色
    [self.progressLineColor setStroke];
    
    [path setLineCapStyle:kCGLineCapRound];
    [path setLineWidth:self.progressLineWidth];
    
    // 画线
    [path stroke];
}

#pragma mark - 设置定时器
- (void)setupTimer
{
    if(_progressTimer == nil)
    {
        
        //定时器间隔时间
        CGFloat timerIntervalTime = self.progressTotalTime * 1.0 / 100;
        
        //定时器应该放在子线程
        _progressTimer = [NSTimer scheduledTimerWithTimeInterval:timerIntervalTime target:self selector:@selector(changeProgress) userInfo:nil repeats:YES];
        
    }
    
}

#pragma mark - 移除定时器
- (void)removeTimer
{
    [self.progressTimer invalidate];
    self.progressTimer = nil;
    
}

#pragma mark - 定时器绑定的方法:修改当前进度
- (void)changeProgress
{
    //如果当前进度小于100,当前进度加1
    if(self.progress < 100)
    {
        self.progress = self.progress + 1;
        
        
    }else //当进度达到100后,移除定时器
    {
        //移除定时器
        [self removeTimer];
        
        if([self.delegate respondsToSelector:@selector(progressEnded:)])
        {
            //执行代理的方法
            [self.delegate progressEnded:self];
            
        }
    }
        
}


@end
