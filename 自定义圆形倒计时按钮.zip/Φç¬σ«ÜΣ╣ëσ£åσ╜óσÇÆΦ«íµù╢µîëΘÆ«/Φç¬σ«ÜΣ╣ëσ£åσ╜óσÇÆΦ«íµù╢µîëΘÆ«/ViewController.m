//
//  ViewController.m
//  自定义圆形倒计时按钮
//
//  Created by 慕容剑飞 on 16/6/10.
//  Copyright © 2016年 jike. All rights reserved.
//

#import "ViewController.h"
#import "MRCycleProgressButton.h"

@interface ViewController ()<MRCycleProgressButtonDelegate>

@property (nonatomic, strong) NSMutableArray *imagesArray;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //设置一个frame
    CGRect frame = CGRectMake(100, 100, 66, 66);
    
    //初始化 请认真阅读关于该方法的介绍说明
    MRCycleProgressButton *progressButton = [[MRCycleProgressButton alloc] initWithFrame:frame ProgressLineWidth:0 ProgressLienColor:nil ProgressTotalTime:0];
    
  
    
    //设置代理
    progressButton.delegate = self;
    
    //添加至父视图
    [self.view addSubview:progressButton];
    
   
    
}

#pragma mark - MRCycleProgressButton的代理方法
- (void)progressEnded:(MRCycleProgressButton *)progressButton
{
    //移除倒计时按钮
    [progressButton removeFromSuperview];
    
    //在此处插入其他代码...
}







@end
