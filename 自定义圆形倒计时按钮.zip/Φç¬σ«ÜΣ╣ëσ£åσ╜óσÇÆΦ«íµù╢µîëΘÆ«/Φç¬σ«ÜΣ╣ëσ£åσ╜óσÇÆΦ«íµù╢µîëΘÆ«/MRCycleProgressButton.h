//
//  ProgressButton.h
//  自定义圆形倒计时按钮
//
//  Created by 慕容剑飞 on 16/6/10.
//  Copyright © 2016年 jike. All rights reserved.
//

//app启动广告界面右上角倒计时按钮
@class MRCycleProgressButton;

#import <UIKit/UIKit.h>

//定义协议
@protocol MRCycleProgressButtonDelegate <NSObject>

@optional

- (void)progressEnded:(MRCycleProgressButton *)progressButton;

@end

@interface MRCycleProgressButton : UIButton

/**
 *  代理属性
 */
@property (nonatomic, weak) id <MRCycleProgressButtonDelegate> delegate;

/**
 *  当前进度:值为整数,范围:0-100
 */
@property (nonatomic, assign) NSInteger progress;

/**
 *  定时器,用于控制进度及按钮中时间的显示
 */
@property (strong, nonatomic) NSTimer *progressTimer;

/**
 *  进度线宽度
 */
@property (nonatomic, assign) CGFloat progressLineWidth;

/**
 *  进度线颜色
 */
@property (nonatomic, strong) UIColor *progressLineColor;

/**
 *  进度从0-100所需时间
 */
@property (nonatomic, assign) NSInteger progressTotalTime;

/**
 *  初始化方法,第一个参数传frame;第二个参数传进度线的宽度;第三个参数传进度线的颜色;第四个参数传进度从0到100所需的总时间
 *
 *  @param frame             自身frame 不能为空
 *  @param progressLienWidth 进度线的宽度 可以传0 默认2.5
 *  @param progressLineColor 进度线颜色 可以传nil 默认红色
 *  @param progressTotalTime 进度从0-100所需总时间 可以传0 默认5秒
 *
 *  @return <#return value description#>
 */
- (instancetype)initWithFrame:(CGRect)frame
            ProgressLineWidth:(CGFloat)progressLineWidth
            ProgressLienColor:(UIColor *)progressLineColor
            ProgressTotalTime:(NSInteger)progressTotalTime;



@end
